# Example Package

Al3X Library


# sendRequestTelegram Method

```
from Al3X import BackTrack

key = ''  # my key

boot = BackTrack(key)

token = '' # your tokens bot in telegram

chatID = '' # chat id for send Message

message = '' # your message

req = boot.sendRequestTelegram(token=token, chatID=chatID, message=message)

print(req)

```

