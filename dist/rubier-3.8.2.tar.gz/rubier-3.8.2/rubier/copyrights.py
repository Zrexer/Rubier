import colors
import os

os.system("")

class ConsoleCopyrights(object):
    def consolePrinter():
        print(f"{colors.colors.MAGENTA}Rubier Library 1.2.0\n{colors.colors.CYAN}Rubino Framework\n\n{colors.colors.END}Started {colors.colors.ORANGE}Rubier{colors.colors.END} as Soon ...\n{colors.colors.LRED}-------------------------{colors.colors.END}\n\n")
